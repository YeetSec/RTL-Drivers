This repo has been updated to build on modern kernels. The procedure
is to be in this directory, i.e. the base directory after doing a 'git clone',
and do 'make' and 'sudo make install'.
