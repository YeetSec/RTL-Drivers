#define DRIVERVERSION	"v5.2.19_xxxx.20171221_beta"
