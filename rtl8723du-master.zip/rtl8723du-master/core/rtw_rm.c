// SPDX-License-Identifier: GPL-2.0
/* Copyright(c) 2007 - 2017 Realtek Corporation */

#include <drv_types.h>
#include <hal_data.h>

#define pstr(s) s+strlen(s)

u8 rm_post_event_hdl(struct adapter *adapt, u8 *pbuf)
{
	return H2C_SUCCESS;
}
