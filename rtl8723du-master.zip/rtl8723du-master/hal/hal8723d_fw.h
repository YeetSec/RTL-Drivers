/* SPDX-License-Identifier: GPL-2.0 */
/* Copyright(c) 2012 - 2017 Realtek Corporation */


#ifndef _FW_HEADER_8723D_H
#define _FW_HEADER_8723D_H

#ifdef LOAD_FW_HEADER_FROM_DRIVER
extern u8 array_mp_8723d_fw_nic[27828];
extern u32 array_length_mp_8723d_fw_nic;
#endif /* end of LOAD_FW_HEADER_FROM_DRIVER */

#endif
