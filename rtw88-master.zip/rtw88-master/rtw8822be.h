/* SPDX-License-Identifier: GPL-2.0 OR BSD-3-Clause */
/* Copyright(c) 2018-2019  Realtek Corporation
 */

#ifndef __RTW_8822BE_H_
#define __RTW_8822BE_H_

extern struct rtw_chip_info rtw8822b_hw_spec;

#endif
